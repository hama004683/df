# IMPORTS # 
import os
"""
Unfinished source code
(bugs maybe + certain commands may not work)
"""
import sys
import asyncio
import aiohttp
import logging
import itertools
import json
import random
import time


try:
    from pystyle import *
except ModuleNotFoundError:
    os.system("pip install pystyle")


try:
    import tasksio
except ModuleNotFoundError:
    os.system("pip install tasksio")


try:
    import discum
except ModuleNotFoundError:
    os.system("pip install discum")


try:
    import pymongo
except ModuleNotFoundError:
    os.system("pip install pymongo")


logging.basicConfig(level=logging.INFO, format="\x1b[38;5;48m[\x1b[0m%(asctime)s\x1b[38;5;48m]\x1b[0m -> %(message)s\x1b[0m",datefmt="%H:%M:%S")


class VoltSpammer:

    def __init__(self):
        self.Clear = lambda: os.system("cls; clear")
        
        self.Tokens = []
        
        self.MassMentionableUsers = []

        for token in open("Data/tokens.txt").read().splitlines(): self.Tokens.append(token)
        
        with open("Data/settings.json") as file:
            try:
                settings = json.load(file)
                self.Use_Proxy = settings["Settings"]["Use Proxies"]
                self.Api = settings["Settings"]["Use Random API"]
                self.UseMultiHooks = settings["Settings"]["Use Multi-Webhooks"]
                self.Delay = settings["Settings"]["Delay"]
                self.Tasks = settings["Settings"]["Tasks"]
                self.Invite = settings["Raid"]["Invite Link"]
                self.MessageSpam = settings["Raid"]["Spam Messages"]
                self.Nicknames = settings["Raid"]["Nickname Changer"]
                if self.Use_Proxy:  self.ProxyPool = itertools.cycle(open("Data/proxies.txt"))
                if self.Api:  self.Api = random.randint(6, 9)
                else: self.Api = 9
                if "discord.gg" in self.Invite or "discord.com" in self.Invite:
                    self.Invite = self.Invite.replace("https://discord.com/invite/", "").replace("https://discord.gg/", "").replace("discord.gg/", "")
            except (Exception) as error:
                logging.error("Err % {}.".format(error))


    

    async def JoinServer(self, token: str):
        try:
            Request_Headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": "__cfduid={}; __dcfduid={}; locale=en-US".format(os.urandom(43).hex(), os.urandom(32).hex()), "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
            json = {"invite": self.Invite}
            if self.Use_Proxy:  proxy = "http://{}".format(next(self.ProxyPool))
            else:  proxy = None
            async with aiohttp.ClientSession(headers=Request_Headers) as self.Session:
                async with self.Session.post("https://discord.com/api/v{}/invites/{}".format(self.Api, self.Invite), json=json, proxy=proxy) as response:
                    if response.status in (200, 200, 204):
                        logging.info("Joined https://discord.gg/{} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(self.Invite, token[:31]))
                    elif response.status == 429:
                        json = await response.json()
                        logging.info("Ratelimited for {}s % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["retry_after"], token[:31])); await asyncio.sleep(1)
                    elif response.status == 403:
                        logging.info("Locked token % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(token[:31]))
                        self.Tokens.remove(token)
                    else:
                        print(await response.text())
                        json = await response.json()
                        logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
        except (aiohttp.client_exceptions.ClientHttpProxyError, Exception) as error:
            logging.error(error)
            return(await self.JoinServer(token))



    async def LeaveServer(self, token: str, GuildID: str):
        try:
            Request_Headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": "__cfduid={}; __dcfduid={}; locale=en-US".format(os.urandom(43).hex(), os.urandom(32).hex()), "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
            if self.Use_Proxy:  proxy = "http://{}".format(next(self.ProxyPool))
            else:  proxy = None
            async with aiohttp.ClientSession(headers=Request_Headers) as self.Session:
                async with self.Session.delete("https://discord.com/api/v{}/users/@me/guilds/{}".format(self.Api, GuildID), proxy=proxy) as response:
                    if response.status in (200, 200, 204):
                        logging.info("Left {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(GuildID, token[:31]))
                    elif response.status == 429:
                        json = await response.json()
                        logging.info("Ratelimited for {}s % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["retry_after"], token[:31])); await asyncio.sleep(1)
                    elif response.status == 403:
                        logging.info("Locked token % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(token[:31]))
                        self.Tokens.remove(token)
                    else:
                        json = await response.json()
                        logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
        except (aiohttp.client_exceptions.ClientHttpProxyError, Exception) as error:
            logging.error(error)
            return(await self.LeaveServer(token, GuildID))



    async def ChangeNickname(self, token: str, GuildID: str):
        try:
            Request_Headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": "__cfduid={}; __dcfduid={}; locale=en-US".format(os.urandom(43).hex(), os.urandom(32).hex()), "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
            json = {"nick": random.choice(self.Nicknames)}
            if self.Use_Proxy:  proxy = "http://{}".format(next(self.ProxyPool))
            else:  proxy = None
            async with aiohttp.ClientSession(headers=Request_Headers) as self.Session:
                async with self.Session.delete("https://discord.com/api/v{}/guilds/{}/members/@me/nick".format(self.Api, GuildID), json=json, proxy=proxy) as response:
                    if response.status in (200, 200, 204):
                        logging.info("Change nickname to {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(random.choice(self.Nicknames), token[:31]))
                    elif response.status == 429:
                        json = await response.json()
                        logging.info("Ratelimited for {}s % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["retry_after"], token[:31])); await asyncio.sleep(1)
                    elif response.status == 403:
                        logging.info("Locked token % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(token[:31]))
                        self.Tokens.remove(token)
                    else:
                        json = await response.json()
                        logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
        except (aiohttp.client_exceptions.ClientHttpProxyError, Exception) as error:
            logging.error(error)
            return(await self.ChangeNickname(token, GuildID))



    async def DmSpammer(self, token: str, UserID: str):
        try:
            Request_Headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": "__cfduid={}; __dcfduid={}; locale=en-US".format(os.urandom(43).hex(), os.urandom(32).hex()), "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
            if self.Use_Proxy:  proxy = "http://{}".format(next(self.ProxyPool))
            else:  proxy = None
            async with aiohttp.ClientSession(headers=Request_Headers) as self.Session:
                async with self.Session.post("https://discord.com/api/v{}/users/@me/channels".format(self.Api), json={"recipient_id": UserID}, proxy=proxy) as response1:
                    if response1.status in (200, 200, 204):
                        json = await response1.json()
                        UserID = json["id"]
                        logging.info("Created a dm with {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(UserID, token[:31]))
                        async with self.Session.post("https://discord.com/api/v{}/channels/{}/messages".format(self.Api, UserID), json={"content": random.choice(self.MessageSpam)}, proxy=proxy) as response:
                            if response.status in (200, 201, 204):
                                logging.info("Sent the message to {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(UserID, token[:31]))
                            elif response.status == 429:
                                json = await response.json()
                                logging.info("Ratelimited for {}s % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["retry_after"], token[:31])); await asyncio.sleep(1)
                            elif response.status == 403:
                                logging.info("Locked token % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(token[:31]))
                                self.Tokens.remove(token)
                            else:
                                json = await response.json()
                                logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
                    else:
                        json = await response1.json()
                        logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
        except (aiohttp.client_exceptions.ClientHttpProxyError, Exception) as error:
            logging.error(error)
            return(await self.DmSpammer(token, UserID))



    async def SpamMessages(self, token: str, ChannelID: str):
        try:
            Request_Headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": "__cfduid={}; __dcfduid={}; locale=en-US".format(os.urandom(43).hex(), os.urandom(32).hex()), "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
            json = {"content": random.choice(self.MessageSpam)}
            if self.Use_Proxy:  proxy = "http://{}".format(next(self.ProxyPool))
            else:  proxy = None
            async with aiohttp.ClientSession(headers=Request_Headers) as self.Session:
                async with self.Session.post("https://discord.com/api/v{}/channels/{}/messages".format(self.Api, ChannelID), json=json, proxy=proxy) as response:
                    if response.status in (200, 200, 204):
                        logging.info("Spammed {} in {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(random.choice(self.MessageSpam), ChannelID, token[:31]))
                    elif response.status == 429:
                        json = await response.json()
                        logging.info("Ratelimited for {}s % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["retry_after"], token[:31])); await asyncio.sleep(1)
                    elif response.status == 403:
                        logging.info("Locked token % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(token[:31]))
                        self.Tokens.remove(token)
                    else:
                        json = await response.json()
                        logging.info("Err % {} % \x1b[38;5;48m(\x1b[0m{}\x1b[38;5;48m).".format(json["message"], token[:31])); await asyncio.sleep(0.333)
        except (aiohttp.client_exceptions.ClientHttpProxyError, Exception) as error:
            logging.error(error)
            return(await self.SpamMessages(token, ChannelID))


    
    async def Menu(self):
        self.Clear()
        if len(self.Tokens) == 0: logging.info("You must have 1 or more tokens to use this application!"); time.sleep(3); os._exit(0)
        print(Colorate.Horizontal(Colors.green_to_cyan, menu, 1))
        print()
        print()
        print("\x1b[38;5;48m-> \x1b[0mCommand\x1b[38;5;48m; ", end="")
        try: command = int(input())
        except: self.Clear; logging.info("The command given, must be a integer."); time.sleep(1); await self.Menu()
        if command == 1:
            os.system("title Volt Spammer % {} Tokens Joining .gg/{}".format(len(self.Tokens), self.Invite))
            self.Clear()
            print(Colorate.Horizontal(Colors.green_to_cyan, text, 1))
            print()
            print()
            logging.info("Selected command {}.".format(command))
            async with tasksio.TaskPool(self.Tasks) as Task:
                logging.info("Started a pool of {} workers.".format(self.Tasks)); await asyncio.sleep(1)
                start = time.time()
                for Token in self.Tokens:
                    await Task.put(self.JoinServer(Token))
                    await asyncio.sleep(self.Delay)
                finish = time.time() - start
                logging.info("Finished inviting token(s) to join discord.gg/{} in {}s.".format(self.Invite, finish)); await asyncio.sleep(3); await self.Menu()
        elif command == 2:
            os.system("title Volt Spammer % Leaving Guild(s)")
            self.Clear()
            print(Colorate.Horizontal(Colors.green_to_cyan, text, 1))
            print()
            print()
            logging.info("Selected command {}.".format(command))
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mEnter Guild ID\x1b[38;5;48m; ", end="")
            try: GuildID = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            async with tasksio.TaskPool(self.Tasks) as Task:
                logging.info("Started a pool of {} workers.".format(self.Tasks)); await asyncio.sleep(1)
                start = time.time()
                for Token in self.Tokens:
                    await Task.put(self.LeaveServer(Token, GuildID))
                    await asyncio.sleep(self.Delay)
                finish = time.time() - start
                logging.info("Token(s) has finished leaving {} in {}s.".format(GuildID, finish)); await asyncio.sleep(3); await self.Menu()
        elif command == 3:
            os.system("title Volt Spammer % Changing Nickname(s)")
            self.Clear()
            print(Colorate.Horizontal(Colors.green_to_cyan, text, 1))
            print()
            print()
            logging.info("Selected command {}.".format(command))
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mEnter Guild ID\x1b[38;5;48m; ", end="")
            try: GuildID = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            async with tasksio.TaskPool(self.Tasks) as Task:
                logging.info("Started a pool of {} workers.".format(self.Tasks)); await asyncio.sleep(1)
                start = time.time()
                for Token in self.Tokens:
                    await Task.put(self.ChangeNickname(Token, GuildID))
                    await asyncio.sleep(self.Delay)
                finish = time.time() - start
                logging.info("Token(s) has finished changing their nickname in {}s.".format(finish)); await asyncio.sleep(3); await self.Menu()
        elif command == 4:
            os.system("title Volt Spammer % DM Spamming User(s)")
            self.Clear()
            print(Colorate.Horizontal(Colors.green_to_cyan, text, 1))
            print()
            print()
            logging.info("Selected command {}.".format(command))
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mEnter User ID\x1b[38;5;48m; ", end="")
            try: UserID = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mAmount To Spam\x1b[38;5;48m; ", end="")
            try: Amount = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            async with tasksio.TaskPool(self.Tasks) as Task:
                logging.info("Started a pool of {} workers.".format(self.Tasks)); await asyncio.sleep(1)
                start = time.time()
                for _ in range(Amount):
                    for Token in self.Tokens:
                        await Task.put(self.DmSpammer(Token, UserID))
                        await asyncio.sleep(self.Delay)
                finish = time.time() - start
                logging.info("Token(s) has finished DM spamming {} in {}s.".format(UserID, finish)); await asyncio.sleep(3); await self.Menu()
        elif command == 5:
            os.system("title Volt Spammer % Spamming Messages In Channel(s)")
            self.Clear()
            print(Colorate.Horizontal(Colors.green_to_cyan, text, 1))
            print()
            print()
            logging.info("Selected command {}.".format(command))
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mEnter Channel ID\x1b[38;5;48m; ", end="")
            try: ChannelID = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            print("\x1b[38;5;48m[\x1b[0m % \x1b[38;5;48m]\x1b[0m -> \x1b[0mAmount To Spam\x1b[38;5;48m; ", end="")
            try: Amount = int(input())
            except: print("bro, how retarded are u."); await asyncio.sleep(2); await self.Menu()
            async with tasksio.TaskPool(self.Tasks) as Task:
                logging.info("Started a pool of {} workers.".format(self.Tasks)); await asyncio.sleep(1)
                start = time.time()
                for _ in range(Amount):
                    for Token in self.Tokens:
                        await Task.put(self.SpamMessages(Token, ChannelID))
                        await asyncio.sleep(self.Delay)
                finish = time.time() - start
                logging.info("Token(s) has finished spamming the channel {} in {}s.".format(ChannelID, finish)); await asyncio.sleep(3); await self.Menu()



"""
 █████╗ ██╗   ██╗████████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██║  ██║
███████║██║   ██║   ██║   ███████║
██╔══██║██║   ██║   ██║   ██╔══██║
██║  ██║╚██████╔╝   ██║   ██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝
                                  
"""


class Authentication:

    def __init__(self):
        os.system("pip install pymongo[srv]")
        self.Clear = lambda: os.system("cls; clear")
        self.MongoClient = pymongo.MongoClient("")
        self.Branch = self.MongoClient.get_database("volt").get_collection("auth")


text = """
:::     :::  ::::::::  :::    ::::::::::: 
:+:     :+: :+:    :+: :+:        :+:     
+:+     +:+ +:+    +:+ +:+        +:+     
+#+     +:+ +#+    +:+ +#+        +#+     
 +#+   +#+  +#+    +#+ +#+        +#+     
  #+#+#+#   #+#    #+# #+#        #+#     
    ###      ########  ########## ###     
"""



menu = """           _......._
       .-'.'.'.'.'.'.`-.                    :::     :::  ::::::::  :::    ::::::::::: 
     .'.'.'.'.'.'.'.'.'.`.                  :+:     :+: :+:    :+: :+:        :+:     
    /.'.'     BETA      '.\                 :+:     :+: :+:    :+: :+:        :+:     
    |.'    _.--...--._     |                +:+     +:+ +:+    +:+ +:+        +:+     
    \    `._.-.....-._.'   /                +#+     +:+ +#+    +:+ +#+        +#+     
    |     _..- .-. -.._   |                  +#+   +#+  +#+    +#+ +#+        +#+     
 .-.'    `.   ((@))  .'   '.-.                #+#+#+#   #+#    #+# #+#        #+#     
( ^ \      `--.   .-'     / ^ )                 ###      ########  ########## ###     
 \  /         .   .       \  /          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 /          .'     '.  .-    \             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
( _.\    \ (_`-._.-'_)    /._\)       
 `-' \   ' .--.          / `-'    ╚╦════════════════════════════════════════════════════════╦╝
     |  / /|_| `-._.'\   |             [ 1 ] % Join Server        [ 5 ] % Spam Messages
     |   |       |_| |   /-.._         [ 2 ] % Leave Server       [ 6 ] 
 _..-\   `.--.______.'  |              [ 3 ] % Change Nickname    [ 7 ] 
      \       .....     |              [ 4 ] % Spam DMs           [ 8 ] 
       `.  .'      `.  /          ╚╦════════════════════════════════════════════════════════╦╝
         \           .'
          `-..___..-`
"""

if __name__ == "__main__":  
    try: asyncio.get_event_loop().run_until_complete(VoltSpammer().Menu()) #asyncio.get_event_loop().run_until_complete(Authentication().Start())
    except (Exception) as error: logging.info(error); time.sleep(1)
